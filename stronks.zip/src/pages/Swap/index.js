import React from 'react';
import Layout from "../../components/Layout";

export default function Swap () {
  return (
    <div>
        Swap
    </div>
  );
};
