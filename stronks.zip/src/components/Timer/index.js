import React from "react";
import "./index.css";

export default function Timer() {
  return (
    <div className="circleContainer">
      <div className="circle">
        <div className="wave">
          <p>0,036%</p>
        </div>
      </div>
    </div>
  );
}
